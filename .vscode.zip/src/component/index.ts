import button from './Button.vue'
import ConfigProvider from './ConfigProvider.vue'

export { button as Button, ConfigProvider }
export default button
