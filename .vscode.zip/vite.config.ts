import { fileURLToPath, URL } from 'node:url'

import { defineConfig, loadEnv } from 'vite'
import vue from '@vitejs/plugin-vue'
import vueJsx from '@vitejs/plugin-vue-jsx'
import vueDevTools from 'vite-plugin-vue-devtools'
import importToCDN from 'vite-plugin-cdn-import'
// @ts-expect-error: no types for postcss-prefix-selector
import prefixer from 'postcss-prefix-selector'
import cssInjectedByJsPlugin from 'vite-plugin-css-injected-by-js'

// https://vite.dev/config/
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')
  const stylePrefix = env.VITE_STYLE_PREFIX || '.vwp'

  return {
    build: {
      cssCodeSplit: false,
      lib: {
        entry: fileURLToPath(new URL('./src/component/index.ts', import.meta.url)),
        name: 'LowCodeComponent',
        formats: ['es', 'umd', 'iife'],
        fileName: (format) => `low-code-component.${format}.js`,
      },
      rollupOptions: {
        external: ['vue'],
        output: {
          globals: {
            vue: 'Vue',
          },
        },
      },
    },
    css: {
      postcss: {
        plugins: [
          prefixer({
            prefix: stylePrefix,
            transform(prefix: string, selector: string, prefixedSelector: string) {
              if (selector === 'body' || selector === 'html') {
                return prefix
              }
              return prefixedSelector
            },
          }),
        ],
      },
    },
    plugins: [
      vue(),
      vueJsx(),
      vueDevTools(),
      cssInjectedByJsPlugin(),
      importToCDN({
        enableInDevMode: true,
        modules: [
          {
            name: 'vue',
            var: 'Vue',
            path: `https://cdn.jsdelivr.net/npm/vue@3.5.13/dist/vue.global.min.js?t=${Date.now()}`, // 添加时间戳
          },
        ],
      }),
    ],
    resolve: {
      alias: {
        '@': fileURLToPath(new URL('./src', import.meta.url)),
      },
    },
  }
})
